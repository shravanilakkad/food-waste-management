 <?php 
    $con = mysqli_connect('localhost','root','','miniproject');
    $sql = "SELECT * FROM  user_table";
    $sql1= "SELECT * FROM orderuser";
    $result = $con->query($sql); 
   
    $result2 = $con-> query($sql1);
  
    ?>
<!DOCTYPE html>
<html>
<head>
    <title>View Page</title>
    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<style>
    body {
             background-image: url('cover1.jpeg');
               background-repeat: no-repeat;
                background-attachment: fixed;
            background-position: center;
             background-size: 100% 100%;
        }    
        form
        {
             text-align: center;
             color:whitesmoke;
        }
         
        input ,.sector,.option1,table
        {
             background-color:rgba(0,0,0,0.5);
             color:white;
        }
        body
        { 
             text-align: center;

        }
        fieldset
        {
              
            text-align: center;
            background-color: rgba(0,0,0,0.5);

        }
        form
        {    align:center;
             max-width: 500px;
           margin: auto;
        }
        .registerbtn
        {
             color: white;
             background-color: blue;
              

        }
        .signin
        {
            color:red;
        }
         .sidenav {
            height: 100%;
            width: 100px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: rgba(0,0,0,0.5);
            overflow-x: hidden;
            padding-top: 20px;
        }

        .sidenav a {
            padding: 6px 4px 4px 30px;
            text-decoration: none;
            font-size: 15px;
            color: #818181;
            display: block;
            background-color:transparent;
        }

        .sidenav a:hover {
            color: #f1f1f1;
        }
/* Back button styles */
.back-button-container {
            margin-top: 20px;
        }

        .back-button {
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        .back-button:hover {
            background-color: #2980b9;
        }
             
        

    </style>
</head>
<body>
    <div class="container">
         <div class="sidenav">
        <a href="dashboard_ngo.html">Home</a>
        <a href="USER_DETAILS.php">User details</a>
        <a href="status.php">Pending request</a>
    </div>

   
        <h2>USERS details</h2>
<table class="table">
    <fieldset>
    <thead>
        <tr>
        <th>ID</th>
        <th> USER Name</th>
        <th>USER Email</th>
         <th>USER CONTACT</th>
          <th>USER ADDRESS</th>
          <th> USER TIFFIN ORDER QUANTITY</th>
             <th> TIME STAMP</th>
    </tr>
     
    </thead>
    <tbody> W
        <?php
                while ($row = $result->fetch_assoc() ) {
        ?>
                    <tr>
                    <td><?php echo $row['user_id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['contact']; ?></td>
                     <td><?php echo $row['address']; ?></td> 
                     
                <?php
                while ($row1 = $result2->fetch_assoc() ) {
        ?>
                       <td><?php echo $row1['tiffin']; ?></td> 
                        <td><?php echo $row1['timestamp']; ?></td>
                   <?php } ?>
        <?php       
                }
        ?>   
         <div class="back-button-container">
        <a href="index.html" class="back-button">Back to Dashboard</a>
    </div>                          
    </tbody>
        </fieldset> 
</table>
    </div> 
</body>
</html>
