<?php
 if (isset($_POST['login'])) {
    $con = mysqli_connect('localhost', 'root', '', 'miniproject');

    // Check connection
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Escape user inputs for security
    $email = mysqli_real_escape_string($con, $_POST["email"]);
    $password = mysqli_real_escape_string($con, $_POST["password"]);

	$sql = "SELECT * FROM ngo_registertable WHERE  email='$email' AND password='$password'";
    $result = mysqli_query($con, $sql);

    if ($result) {
        $num = mysqli_num_rows($result);

        if ($num > 0) {
            $row = mysqli_fetch_array($result);
            if ($row) {
                header("Location: dashboard_ngo.html");
                exit();
            }
        } else {
            echo "Invalid email or password.";
        }
    } else {
        echo "Error: " . mysqli_error($con);
    }

     
}

?>
<hr>
<font color="red"><b>
		<h3>Sorry Invalid Username and Password<br>
			Please Enter Correct Credentials</br></h3>
	</b>
</font>
<hr>

<?php
?>
<html>
 
<head>
  </head>
<style>
	 form,input,.form-login-heading
	{
		background-color:rgba(0,0,0,0.5);
		color:white;
		 max-width: 500px;
        margin: auto;
		
	}
	  body {
             background-image: url('cover1.jpeg');
               background-repeat: no-repeat;
                background-attachment: fixed;
            background-position: center;
             background-size: 100% 100%;
        }   
		fieldset
		{
			text-align: center;
			  margin: auto;
			  	 max-width: 500px;
				 background-color:rgba(0,0,0,0.5);
		}    
		.form-login-heading 
		{
			color:white;
		}
		.btn
		{
			background-color:rgba(0,0,0,0.5);
			color:white;
		}
		.form-control,.modal-header
		{
			background-color:rgba(0,0,0,0.5);
			color:white;
		}
		.modal-body,.registration
		{
			color:red;
		}
		th,p
		{
			color:white;
		}
		h1,a
		{
			color:red;
		}
		td
		{
			 text-align: center;
		}
		ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
			 
        }
		a
		{
			color: white;
		}

		

</style>>   

  <body>
   
		<form action="ngo_login.php" method="post">
		<fieldset>
			<legend align="center">
				<h1 align="center"> NGO LOGIN</h1>
			</legend>
			<table width="50%" border="1"
				align="center" style="border:thick;">
				<tr>
					<th height="40"><label for="email">
						Email</label>
					</th>
					<td><input type="text" name="email"
							id="email" required>
						</td>
				</tr>
				<tr>
					<th height="40"><label for="pwd">
						Password
					</label>
					</th>
					<td><input type="password"
						name="password" id="password" required></td>
				</tr>
				<tr>
					<td colspan="2" height="40"><input
						type="submit" name="login"
						value="Login" class="login"></td></tr>
					<tr>
					<td colspan="3">
						<div class="container signin">
                    <p>New user connect us? <a href="/project/serviceprovider/service_provider.html">Register here</a>.</p>
                </div>
					</td>

				</tr>
			</table>
		</fieldset>
	</form>
</body>

</html>



      
	 