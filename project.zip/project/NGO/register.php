<?php
  
$con  = mysqli_connect('localhost','root','','miniproject');
  
if(isset($_POST['submit'])) {
    $query = mysqli_query($con,
    "INSERT INTO ngo_registertable SET 
    uname='". $_POST["uname"] . "'  ,
    address ='". $_POST["address"] . "'   ,
    contact ='". $_POST["contact"] . "'    ,
    email     ='". $_POST["email"] . "'     ,  
    contact     ='". $_POST["contact"] . "'        ,
    password     ='". $_POST["password"] . "'        ,
    confirm_password     ='". $_POST["confirm_password"] . "'        ,
    sector ='". $_POST["sector"] . "'           '");
      
?>
<script>
    alert('You Registered Successfully, Login now');
</script>
<?php
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
             body {
             background-image: url('cover1.jpeg');
               background-repeat: no-repeat;
                background-attachment: fixed;
            background-position: center;
             background-size: 100% 100%;
        }    
        form
        {
             text-align: center;
             color:whitesmoke;
              background-color:rgba(0,0,0,0.5);
        }
         
        input ,.sector,.option1
        {
             background-color:rgba(0,0,0,0.5);
             color:white;
        }
        body
        { 
             text-align: center;

        }
        fieldset
        {
              
            text-align: center;
            background-color: rgba(0,0,0,0.5);

        }
        form
        {    align:center;
             max-width: 500px;
           margin: auto;
        }
        .registerbtn
        {
             color: white;
             background-color: blue;
              

        }
        .signin
        {
            color:red;
        }
        p{color:antiquewhite;}
 
    </style>
</head>

<body>

    <form action="index.php" method="post">
        <div class="container">
            <h1>Register</h1>
            <p>Please fill in this form to create an account.</p>
            <hr>
            <label for="uname">Name</label>
            <input type="text" name="uname" id="uname" placeholder="Enter NGO name" ><br><br>

            <label for="address"><b>Address</b></label>
            <input type="text"   name="address" id="address" placeholder="Enter Address"><br><br>
            <label for="Ngo_contact">Contact No</label>
            <input type="number"  name="Ngo_contact" id="Ngo_contact" placeholder="Enter contact "><br><br>
            <label for="email">Email</label>
            <input type="text"  name="email" id="email" placeholder="Enter your email"><br><br>

            <label for="password">Password</label>
            <input type="password" placeholder="Enter Password" name="password" id="password" ><br><br>

            <label for="pswconfirm"><b>Repeat Password</b></label>
            <input type="password"  name="pswconfirm" id="pswconfirm" placeholder="Confirm Password"  ><br><br>
            <br><label for="sector">Choose your working sector:</label>
            <select name="sector" id="sector" class="sector">
                <option value="Governmental" name="sector">Governmental</option>
                <option value="Non-Governmental" name="sector">Non-Governmental</option>
                <option value="Charitable" name="sector">Charitable</option>
            </select><br><br>
            <hr>
            

            <button type="submit" class="registerbtn">Register</button>
        </div>

        <div class="container signin">
            <p>Already have an account? <a href="/project/NGO/ngo_login.php">Sign in</a>.</p>
        </div>
    </form>

</body>

</html>