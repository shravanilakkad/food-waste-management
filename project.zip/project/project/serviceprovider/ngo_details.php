 
  <?php 
    $con = mysqli_connect('localhost','root','','miniproject');
    $sql = "SELECT * FROM  ngo_registertable";
    $sql2 = "SELECT * FROM ngodecision"; 
    $result = $con->query($sql);
     $result1 = $con->query($sql2);
    ?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: "Lato", sans-serif;
            background-image: url('cover1.jpeg');
        }

        .sidenav {
            height: 100%;
            width: 200px;
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.5);
            overflow-x: hidden;
            padding-top: 20px;
        }

        .sidenav a {
            padding: 6px 6px 6px 32px;
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
        }

        .sidenav a:hover {
            color: #f1f1f1;
        }

        .main {
            margin-left: 200px;
            /* Same as the width of the sidenav */
        }

        @media screen and (max-height: 450px) {
            .sidenav {
                padding-top: 15px;
            }

            .sidenav a {
                font-size: 18px;
            }
        }

        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: left;
            border-right: 1px solid #bbb;

        }

        li:last-child {
            border-right: none;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover:not(.active) {
            background-color: transparent;
        }

        .active {
            background-color: #04AA6D;
        }
        input ,.table1
        {
             background-color:rgba(0,0,0,0.5);
             color:white;
             text-align:center;
            margin-left: auto;
              margin-right: auto;
        }
        body
        { 
             text-align: center;

        }
        fieldset
        {
              
            text-align: center;
            background-color: rgba(0,0,0,0.5);
            width: 500px;
            margin-left: auto;
              margin-right: auto;

        }
        th
        {
            color:red;
        }
        h1
        {
            color:white;
        }
        
    </style>
</head>

<body>
    <ul>

        <li style="float:right"><a href="users_login.php">logout</a></li>
    </ul>
    <div class="sidenav">
        <a href="dashboard_user.html">Home</a>
        <a href="ngo_details.php">NGO DETAILS </a>
        <a href="delieverorder.php">USER DETAILS </a>

    </div>
    <br>
    <br>
    <br>
    <br>
    <fieldset>
        <h1>NGO DETAILS</h1>
     
    <table class="table1">
  <tr>
        <th>NGO Name</th>
        <th></th>
        <th>NGO Email</th>
        <th></th>
         <th>NGO SECTOR</th>
         <th></th>
         <Th>Order status</th>
            <th></th>
    </tr>
     
    </thead>
    <tbody> 
        <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
        ?>
                    <tr>
                    <td><?php echo $row['uname']; ?></td>
                    <td></td>
                    <td><?php echo $row['email']; ?></td>
                    <td></td>
                    <td><?php echo $row['sector']; ?></td>
                    <td></td>
              <?php  if ($result1->num_rows > 0) {
                while ($row2 = $result1->fetch_assoc()) {
        ?>
            <td><?php echo $row2['decision']; ?></td> </tr>
        <?php
    } } } } ?>
    </table>
</fieldset>
                
                
    <div class="main">
         <?php 
            
         
         ?>
    </div>

</body>

</html>