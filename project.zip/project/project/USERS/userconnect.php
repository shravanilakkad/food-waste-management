<?php
    $con = mysqli_connect('localhost','root','','miniproject');  
    if($con)
        echo"connection successful";
    $name =$_POST['name'];  
    $email = $_POST['email'];
    $contact = $_POST['contact'];
      $address = $_POST['address'];
         $psw = $_POST['psw'];
         $pswconfirm = $_POST['pswconfirm'];
 $sql= "INSERT INTO `userrecord`( `name`, `email`, `contact`, `address`, `psw`, `pswconfirm`) VALUES ('$name','$email','$contact','$address','$psw','$pswconfirm')";
  $result = $con->query($sql);  
    if($result) 
        echo " ngo : $name Record successfully  ";   
?>
