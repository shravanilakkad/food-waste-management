 <?php 
    $con = mysqli_connect('localhost','root','','miniproject');
    $sql = "SELECT * FROM  ngo_registertable";
    $result = $con->query($sql); ?>
<!DOCTYPE html>
<html>
<head>
    <title>View Page</title>
    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<style>
     ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
            background-color: #333;
        }

        li {
            float: left;
            border-right: 1px solid #bbb;
        }

        li:last-child {
            border-right: none;
        }

        li a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        li a:hover:not(.active) {
            background-color: #111;
        }

        .active {
            background-color: #04AA6D;
        }
    body {
             background-image: url('cover1.jpeg');
               background-repeat: no-repeat;
                background-attachment: fixed;
            background-position: center;
             background-size: 100% 100%;
        }    
        form
        {
             text-align: center;
             color:whitesmoke;
        }
         
        input ,.sector,.option1,table
        {
             background-color:rgba(0,0,0,0.5);
             color:white;
        }
        body
        { 
             text-align: center;

        }
        fieldset
        {
              
            text-align: center;
            background-color: rgba(0,0,0,0.5);

        }
        form
        {    align:center;
             max-width: 500px;
           margin: auto;
        }
        .registerbtn
        {
             color: white;
             background-color: blue;
              

        }
        .signin
        {
            color:red;
        }
             
        

    </style>
</head>
<body>
   
     <h2>NGO details</h2>
<table class="table">
    <fieldset>
    <thead>
        <tr>
        <th>ID</th>
        <th>NGO Name</th>
        <th>NGO Email</th>
         <th>NGO SECTOR</th>
         <th> NGO Tiffin Stock</th>
    </tr>
     
    </thead>
    <tbody> 
        <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
        ?>
                    <tr>
                    <td><?php echo $row['ngo_id']; ?></td>
                    <td><?php echo $row['uname']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['sector']; ?></td>
                    <td><form action="orderindex.php" method="post" >Order: <input type="number" name="tiffin" class="tiffin" id="tiffin"> </td>
                     <td><button type="submit" class="registerbtn">Order</button> </form></td>
                    </tr>     
        <?php       }
            }
        ?>                
             
             
    </tbody>
        </fieldset> 
</table>
    </div> 
</body>
</html>
