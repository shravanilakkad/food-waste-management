<?php
         $con = mysqli_connect('localhost','root','','miniproject');  
    $tiffin=  $_POST['tiffin'];  
     
    $sql = "INSERT INTO `orderuser`( `tiffin`) VALUES ('$tiffin')";
    $result = $con->query($sql);  
    if($result) 
        echo "$tiffin Record Order Succesfully added"; 

?>