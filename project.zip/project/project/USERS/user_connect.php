<?php
    $con = mysqli_connect('localhost','root','','miniproject');  
    if($con)
        echo"connection successful";
    $name =$_POST['name'];  
    $email = $_POST['email'];
    $contact = $_POST['contact'];
      $address = $_POST['address'];
         $psw = $_POST['psw'];
         $pswconfirm = $_POST['pswconfirm'];
 $sql= "INSERT INTO `user_table`(`user_id`, `name`, `email`, `contact`, `address`, `password`, `confirm_password`) VALUES (0,'$name','$email','$contact','$address','$psw','$pswconfirm')";
  $result = $con->query($sql);  
    if($result) 
        echo "$name Record successfully added $email and its status is :  ";  
    else
    echo "Querry"; 
    ?>
